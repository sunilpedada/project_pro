



<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark"> <a class="navbar-brand" href="#">LIL PROJECTS </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active"> <a class="nav-link" href="#">Tasks <span class="sr-only">(current)</span></a> </li>
        <li class="nav-item dropdown"> <a class="nav-link btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">manoj+102@edgecase.ai </a>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> <a class="dropdown-item" href="#">Action</a> <a class="dropdown-item" href="#">Another action</a> <a class="dropdown-item" href="#">Something else here</a> </div>
        </li>
      </ul>
    </div>
  </nav>
</header>
<div class="container-fluid">
  <div class="main_top new_data">

   			<div class="row">
            	<div class="col-sm-12">
                	<h2>Create Project
<a href="#"><i class="fa fa-times" aria-hidden="true"></i></a>
</h2>
                </div>


                	<div class="list_count">

                    	<ul>
                        	<li>
                            	<h4><span>1</span>Name your project</h4>
                                <div class="form_box">
                                	<form action="#">
                                      <div class="form-group">

                                        <input type="email" class="form-control" placeholder="Email" id="email">
                                      </div>
                                      <div class="form-group">

                                        <input type="password" class="form-control" placeholder="Password" id="pwd">
                                      </div>

                                      <a href="create-project-2.html"  class="btn btn-dark">Next</a>
                                    </form>
                                </div>
                            </li>

                            <li>
                            	<h4><span>2</span>Attach a dataset</h4>
                                <div class="form_box">

                                </div>
                            </li>

                            <li>
                            	<h4><span>3</span>Customize your label editor</h4>
                                <div class="form_box">

                                </div>
                            </li>

                        </ul>

                    </div>


            </div>

  </div>
</div>
